# منصة Students IS التعليمية — Next.js

جامعة البيان · كلية علوم الحاسوب وتقانة المعلومات · قسم نظم المعلومات

مبنية بـ **Next.js 14** (تصدير ثابت Static Export) + **Supabase** (تسجيل الدخول والتخزين) + استضافة **Netlify**.

## ⚠️ الإعداد لأول مرة (بالترتيب)

1. **Supabase ← SQL Editor**: افتح `supabase/schema.sql`، غيّر `ADMIN_EMAIL_HERE` ببريد حساب الأدمن الحالي، ثم شغّله كاملاً.
   - بدون هذه الخطوة لن تعمل صفحة الأدمن، وصلاحيات الطلاب لن تكون محمية.
   - بعد التشغيل راجع السياسات القديمة (التعليمات في آخر الملف).
2. **Supabase ← Authentication ← Providers**: تأكد أن Email مفعّل. في **URL Configuration** ضع رابط موقعك على Netlify في `Site URL` وأضفه إلى `Redirect URLs` (لرابط استعادة كلمة المرور).
   - إن أردت أن يدخل الطالب مباشرة بعد التسجيل، عطّل "Confirm email".
3. **GitHub**: ارفع محتويات هذا المجلد إلى المستودع المربوط بـ Netlify (استبدل الملفات القديمة).
4. **Netlify ← Site configuration ← Build & deploy**:
   - Build command: `npm run build`
   - Publish directory: `out`
   - (الملف `netlify.toml` يضبطهما تلقائياً، فإن ظهر تعارض امسح القيم القديمة من لوحة Netlify.)
5. (اختياري) ضع متغيرات البيئة من `.env.example` في Netlify. إن لم تضعها يستخدم المشروع القيم الحالية.

## التعديل من GitHub (يظهر مباشرة في المنصة)

كل `commit` على المستودع يُنشر تلقائياً على Netlify خلال دقائق. الملفات التي تُعدَّل عادةً:

| الملف | ما تغيّره فيه |
|---|---|
| `src/data/semesters.js` | إضافة مادة أو سمستر |
| `src/data/files.js` | روابط المحاضرات والشيتات والامتحانات |
| `src/data/questions.js` | أسئلة الاختيار من متعدد |
| `src/data/aliases.js` | أسماء عربية بديلة للمواد (للبحث) |

## الخطوط

- English: **Inter** (الأساسي) · **Sora** (العناوين) · **JetBrains Mono** (الأكواد والأرقام)
- العربي: **Amiri Bold** (العناوين) · **IBM Plex Sans Arabic Regular** (النص) · **Cairo SemiBold** (الواجهة)

تُحمَّل عبر `next/font` في `src/app/layout.js`، وتُطبَّق في آخر `src/app/globals.css`.

## الصفحات

- `/login` — دخول الطلاب وإنشاء الحساب واستعادة كلمة المرور
- `/` — الرئيسية، `/tasks`، `/about`، `/subject/...` — محمية بتسجيل الدخول
- `/admin` — لوحة الأدمن (نفس واجهة الدخول). الرابط يظهر بالضغط 5 مرات على شعار الفوتر.

## التشغيل محلياً

```bash
npm install
npm run dev
```

## منح صلاحية أدمن لحساب آخر

```sql
update public.profiles set role = 'admin' where email = 'someone@example.com';
```
