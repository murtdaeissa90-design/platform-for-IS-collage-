// أدوات مشتركة بين كل الـ Edge Functions
import { createClient, SupabaseClient, User } from "npm:@supabase/supabase-js@2";

// ---------------------------------------------------------------------
// CORS: يسمح للمتصفح باستدعاء الدالة من موقع Netlify.
// لتقييده بموقعك فقط ضع السر ALLOWED_ORIGIN=https://computer-is-collage.netlify.app
// ---------------------------------------------------------------------
const ORIGIN = Deno.env.get("ALLOWED_ORIGIN") || "*";

export const corsHeaders = {
  "Access-Control-Allow-Origin": ORIGIN,
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
  });
}

/** يرد على طلب OPTIONS (preflight) الذي يرسله المتصفح قبل POST */
export function preflight(req: Request): Response | null {
  return req.method === "OPTIONS" ? new Response("ok", { headers: corsHeaders }) : null;
}

// ---------------------------------------------------------------------
// عميلان لـ Supabase:
//  - admin: مفتاح service_role (يتجاوز RLS) — يُستخدم داخل السيرفر فقط
//  - من توكن المستخدم نتحقق: من هو؟
// SUPABASE_URL و SUPABASE_SERVICE_ROLE_KEY يضيفهما Supabase تلقائياً للدوال.
// ---------------------------------------------------------------------
export function adminClient(): SupabaseClient {
  return createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
    auth: { persistSession: false },
  });
}

/** يتحقق من توكن الدخول في ترويسة Authorization ويرجع المستخدم، أو null */
export async function getUser(req: Request, admin: SupabaseClient): Promise<User | null> {
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "").trim();
  if (!token) return null;
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data?.user) return null;
  return data.user;
}

/** هل هذا المستخدم أدمن؟ (من جدول profiles، لا من أي شيء يرسله المتصفح) */
export async function isAdmin(admin: SupabaseClient, userId: string): Promise<boolean> {
  const { data } = await admin.from("profiles").select("role").eq("id", userId).maybeSingle();
  return data?.role === "admin";
}

// نفس دالة slugify الموجودة في src/lib/subjects.js (لبناء روابط المواد)
export const slugify = (name: string) =>
  String(name)
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
