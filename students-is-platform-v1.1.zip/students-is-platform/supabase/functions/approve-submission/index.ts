// approve-submission
// الأدمن يوافق على ملف مرفوع → الدالة:
//   1) تتحقق أن المستدعي أدمن فعلاً
//   2) تغيّر approved إلى true
//   3) تُدرج إشعاراً للطالب صاحب الملف (يظهر في الجرس 🔔)
//   4) (اختياري) ترسل له بريداً عبر Resend إن وُجد RESEND_API_KEY
//
// الطلب:  POST { "submission_id": "<id>" }   مع ترويسة Authorization: Bearer <توكن الأدمن>
// الرد:   { ok: true, notified: true|false, emailed: true|false }
import { adminClient, getUser, isAdmin, json, preflight, slugify } from "../_shared/common.ts";

const SITE_URL = Deno.env.get("SITE_URL") || "https://computer-is-collage.netlify.app";

const escapeHtml = (s: string) =>
  s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));

async function sendEmail(to: string, fileName: string, subject: string, link: string): Promise<boolean> {
  const key = Deno.env.get("RESEND_API_KEY");
  if (!key) return false; // البريد اختياري
  const from = Deno.env.get("MAIL_FROM") || "Students IS <onboarding@resend.dev>";
  const name = escapeHtml(fileName);
  const html = `
    <div dir="rtl" style="font-family:Tahoma,Arial,sans-serif;line-height:1.8">
      <h2>✅ تمت الموافقة على ملفك</h2>
      <p>الملف «<b>${name}</b>» في مادة <b>${escapeHtml(subject)}</b> أصبح متاحاً لكل الطلاب على المنصة. شكراً لمساهمتك!</p>
      <p><a href="${link}">فتح الملف في المنصة</a></p>
      <hr><div dir="ltr" style="color:#555">
        Your file "<b>${name}</b>" in <b>${escapeHtml(subject)}</b> has been approved and is now visible to everyone. Thank you!
      </div>
    </div>`;
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to: [to], subject: "✅ تمت الموافقة على ملفك | Your file was approved", html }),
    });
    if (!res.ok) console.error("Resend error:", res.status, await res.text());
    return res.ok;
  } catch (e) {
    console.error("Resend failed:", e);
    return false;
  }
}

Deno.serve(async (req) => {
  const pre = preflight(req);
  if (pre) return pre;
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const admin = adminClient();

  // 1) من المستدعي؟ وهل هو أدمن؟
  const user = await getUser(req, admin);
  if (!user) return json({ error: "unauthorized" }, 401);
  if (!(await isAdmin(admin, user.id))) return json({ error: "forbidden" }, 403);

  // 2) قراءة المدخلات والتحقق منها
  let body: { submission_id?: unknown };
  try {
    body = await req.json();
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  const id = body.submission_id;
  if (typeof id !== "string" && typeof id !== "number") return json({ error: "submission_id_required" }, 400);

  // 3) جلب الملف
  const { data: row, error: getErr } = await admin.from("submissions").select("*").eq("id", id).maybeSingle();
  if (getErr) {
    console.error(getErr);
    return json({ error: "db_error" }, 500);
  }
  if (!row) return json({ error: "not_found" }, 404);
  if (row.approved) return json({ ok: true, already: true, notified: false, emailed: false });

  // 4) الموافقة
  const { error: updErr } = await admin.from("submissions").update({ approved: true }).eq("id", id);
  if (updErr) {
    console.error(updErr);
    return json({ error: "approve_failed" }, 500);
  }

  // 5) إشعار الطالب (إن كان الملف مرتبطاً بحساب)
  let notified = false;
  let emailed = false;
  if (row.user_id) {
    const path = `/subject/${slugify(row.subject)}/${encodeURIComponent(row.material)}/`;
    const fileName = String(row.name || "");
    const { error: nErr } = await admin.from("notifications").insert({
      user_id: row.user_id,
      kind: "file_approved",
      title_ar: "✅ تمت الموافقة على ملفك",
      title_en: "✅ Your file was approved",
      body_ar: `الملف «${fileName}» في مادة ${row.subject} أصبح متاحاً للجميع. شكراً لمساهمتك!`,
      body_en: `"${fileName}" in ${row.subject} is now visible to everyone. Thanks for contributing!`,
      link: path,
    });
    if (nErr) console.error("notification insert failed:", nErr);
    else notified = true;

    const { data: prof } = await admin.from("profiles").select("email").eq("id", row.user_id).maybeSingle();
    if (prof?.email) emailed = await sendEmail(prof.email, fileName, row.subject, SITE_URL + path);
  }

  return json({ ok: true, notified, emailed });
});
