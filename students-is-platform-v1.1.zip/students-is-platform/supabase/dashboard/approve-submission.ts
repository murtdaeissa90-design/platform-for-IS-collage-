// approve-submission (نسخة ملف واحد للصق في محرر Supabase)
import { createClient, SupabaseClient, User } from "npm:@supabase/supabase-js@2";

const ORIGIN = Deno.env.get("ALLOWED_ORIGIN") || "*";

const corsHeaders = {
  "Access-Control-Allow-Origin": ORIGIN,
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
  });
}

/** يرد على طلب OPTIONS (preflight) الذي يرسله المتصفح قبل POST */
function preflight(req: Request): Response | null {
  return req.method === "OPTIONS" ? new Response("ok", { headers: corsHeaders }) : null;
}

function adminClient(): SupabaseClient {
  return createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
    auth: { persistSession: false },
  });
}

/** يتحقق من توكن الدخول في ترويسة Authorization ويرجع المستخدم، أو null */
async function getUser(req: Request, admin: SupabaseClient): Promise<User | null> {
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "").trim();
  if (!token) return null;
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data?.user) return null;
  return data.user;
}

/** هل هذا المستخدم أدمن؟ (من جدول profiles، لا من أي شيء يرسله المتصفح) */
async function isAdmin(admin: SupabaseClient, userId: string): Promise<boolean> {
  const { data } = await admin.from("profiles").select("role").eq("id", userId).maybeSingle();
  return data?.role === "admin";
}

const slugify = (name: string) =>
  String(name)
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

const SITE_URL = Deno.env.get("SITE_URL") || "https://computer-is-collage.netlify.app";

const escapeHtml = (s: string) =>
  s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));

async function sendEmail(to: string, fileName: string, subject: string, link: string): Promise<boolean> {
  const key = Deno.env.get("RESEND_API_KEY");
  if (!key) return false; // البريد اختياري
  const from = Deno.env.get("MAIL_FROM") || "Students IS <onboarding@resend.dev>";
  const name = escapeHtml(fileName);
  const html = `
    <div dir="rtl" style="font-family:Tahoma,Arial,sans-serif;line-height:1.8">
      <h2>✅ تمت الموافقة على ملفك</h2>
      <p>الملف «<b>${name}</b>» في مادة <b>${escapeHtml(subject)}</b> أصبح متاحاً لكل الطلاب على المنصة. شكراً لمساهمتك!</p>
      <p><a href="${link}">فتح الملف في المنصة</a></p>
      <hr><div dir="ltr" style="color:#555">
        Your file "<b>${name}</b>" in <b>${escapeHtml(subject)}</b> has been approved and is now visible to everyone. Thank you!
      </div>
    </div>`;
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to: [to], subject: "✅ تمت الموافقة على ملفك | Your file was approved", html }),
    });
    if (!res.ok) console.error("Resend error:", res.status, await res.text());
    return res.ok;
  } catch (e) {
    console.error("Resend failed:", e);
    return false;
  }
}

Deno.serve(async (req) => {
  const pre = preflight(req);
  if (pre) return pre;
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const admin = adminClient();

  // 1) من المستدعي؟ وهل هو أدمن؟
  const user = await getUser(req, admin);
  if (!user) return json({ error: "unauthorized" }, 401);
  if (!(await isAdmin(admin, user.id))) return json({ error: "forbidden" }, 403);

  // 2) قراءة المدخلات والتحقق منها
  let body: { submission_id?: unknown };
  try {
    body = await req.json();
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  const id = body.submission_id;
  if (typeof id !== "string" && typeof id !== "number") return json({ error: "submission_id_required" }, 400);

  // 3) جلب الملف
  const { data: row, error: getErr } = await admin.from("submissions").select("*").eq("id", id).maybeSingle();
  if (getErr) {
    console.error(getErr);
    return json({ error: "db_error" }, 500);
  }
  if (!row) return json({ error: "not_found" }, 404);
  if (row.approved) return json({ ok: true, already: true, notified: false, emailed: false });

  // 4) الموافقة
  const { error: updErr } = await admin.from("submissions").update({ approved: true }).eq("id", id);
  if (updErr) {
    console.error(updErr);
    return json({ error: "approve_failed" }, 500);
  }

  // 5) إشعار الطالب (إن كان الملف مرتبطاً بحساب)
  let notified = false;
  let emailed = false;
  if (row.user_id) {
    const path = `/subject/${slugify(row.subject)}/${encodeURIComponent(row.material)}/`;
    const fileName = String(row.name || "");
    const { error: nErr } = await admin.from("notifications").insert({
      user_id: row.user_id,
      kind: "file_approved",
      title_ar: "✅ تمت الموافقة على ملفك",
      title_en: "✅ Your file was approved",
      body_ar: `الملف «${fileName}» في مادة ${row.subject} أصبح متاحاً للجميع. شكراً لمساهمتك!`,
      body_en: `"${fileName}" in ${row.subject} is now visible to everyone. Thanks for contributing!`,
      link: path,
    });
    if (nErr) console.error("notification insert failed:", nErr);
    else notified = true;

    const { data: prof } = await admin.from("profiles").select("email").eq("id", row.user_id).maybeSingle();
    if (prof?.email) emailed = await sendEmail(prof.email, fileName, row.subject, SITE_URL + path);
  }

  return json({ ok: true, notified, emailed });
});
