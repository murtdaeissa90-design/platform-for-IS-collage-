# 🎓 منصة Students IS التعليمية

منصة تعليمية لتنظيم المواد الجامعية والمحاضرات والشيتات والامتحانات وأسئلة المراجعة.
**جامعة البيان · كلية علوم الحاسوب وتقانة المعلومات · قسم نظم المعلومات**

🌐 الموقع: https://computer-is-collage.netlify.app

## المميزات

- حسابات للطلاب (إنشاء حساب، دخول، استعادة كلمة المرور) عبر Supabase Auth
- لوحة أدمن محمية: مراجعة الملفات المرفوعة، الموافقة، الحذف، والبحث عن الطلاب
- بحث تلقائي يتحمل الأخطاء الإملائية (عربي وإنجليزي) في المواد والمحاضرات والشيتات والامتحانات
- رفع الطلاب للملفات (تظهر بعد موافقة الأدمن)
- أسئلة اختيار من متعدد ثنائية اللغة
- مهام المذاكرة، المفضلة، والعد التنازلي للامتحانات (محفوظة في متصفح الطالب)
- واجهة عربية/إنجليزية (RTL/LTR) ووضع ليلي
- 🔔 إشعارات للطالب عند الموافقة على ملفه (وبريد اختياري) عبر Supabase Edge Functions
- 🤖 مساعد ذكي (Claude) يجيب الطلاب عن المنصة ويجلب لهم الملفات وأسئلة المراجعة

## التقنيات

| الجزء | التقنية |
|---|---|
| الواجهة | Next.js 14 (App Router) + React 18، تصدير ثابت `output: "export"` |
| الحسابات والبيانات والتخزين | Supabase (Auth + Postgres + Storage) |
| الـ API والمساعد الذكي | Supabase Edge Functions (Deno/TypeScript) + Anthropic API |
| الاستضافة والنشر | Netlify (ينشر تلقائياً من GitHub) |

## الخطوط

- English: **Inter** (الأساسي) · **Sora** (العناوين) · **JetBrains Mono** (الأكواد والأرقام)
- العربي: **Amiri Bold** (العناوين) · **IBM Plex Sans Arabic Regular** (النص) · **Cairo SemiBold** (الواجهة)

## ابدأ من هنا

| أريد أن... | اقرأ |
|---|---|
| أجهّز المشروع لأول مرة (Supabase + Netlify) | [docs/SETUP.md](docs/SETUP.md) |
| أضيف مادة أو رابط أو أسئلة | [docs/EDITING.md](docs/EDITING.md) |
| أفهم أين يوجد كل ملف | [docs/STRUCTURE.md](docs/STRUCTURE.md) |
| أركّب الـ API (الإشعارات والمساعد الذكي) | [docs/API.md](docs/API.md) |
| أفهم الصلاحيات والحماية | [docs/SECURITY.md](docs/SECURITY.md) |
| أحل مشكلة ظهرت | [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) |
| أعرف ما تغيّر | [CHANGELOG.md](CHANGELOG.md) |

## التشغيل محلياً

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # ينتج مجلد out
```

## المطورون

مرتضى عيسى · عبدالله إسماعيل — © 2026 جميع الحقوق محفوظة
